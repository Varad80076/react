

const allMessages = {
    
    errmsg : ' this is error varad',
    ENDPOINT: 'Login endpoint not found',
    CHECK_CREDENTIALS:"Please! Check Your Credentials."
}

export default allMessages