//import mongoose and create connection with database
const mongoose = require('mongoose');
mongoose.connect('mongodb+srv://VaradBadgujar:%40amlpfrt%40wiy%40V%406347@portfolio.doncl.mongodb.net/');
